import { http } from '@google-cloud/functions-framework';
import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { getStorage } from 'firebase-admin/storage';
import Busboy from 'busboy';
import { Readable } from 'stream';

// Initialize Firebase Admin (once)
if (!getApps().length) {
  initializeApp({
    credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)),
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  });
}

const db = getFirestore();
const auth = getAuth();
const storage = getStorage().bucket();

// ─── CORS helper ────────────────────────────────────────────────────────────
function cors(req, res) {
  res.set('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || '*');
  res.set('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') { res.status(204).send(''); return true; }
  return false;
}

// ─── Auth middleware ─────────────────────────────────────────────────────────
async function verifyToken(req, res) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) { res.status(401).json({ error: 'Missing token' }); return null; }
  try {
    return await auth.verifyIdToken(token);
  } catch {
    res.status(401).json({ error: 'Invalid token' }); return null;
  }
}

// ─── Parse multipart upload ──────────────────────────────────────────────────
function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    const bb = Busboy({ headers: req.headers });
    const fields = {};
    const files = [];
    bb.on('field', (name, val) => { fields[name] = val; });
    bb.on('file', (name, stream, info) => {
      const chunks = [];
      stream.on('data', d => chunks.push(d));
      stream.on('end', () => files.push({ name, buffer: Buffer.concat(chunks), info }));
    });
    bb.on('finish', () => resolve({ fields, files }));
    bb.on('error', reject);
    if (Buffer.isBuffer(req.rawBody)) {
      Readable.from(req.rawBody).pipe(bb);
    } else {
      req.pipe(bb);
    }
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN FUNCTION
// ═══════════════════════════════════════════════════════════════════════════════
http('api', async (req, res) => {
  if (cors(req, res)) return;

  const path = req.path || '/';
  const method = req.method;

  // ── GET /channels ──────────────────────────────────────────────────────────
  if (path === '/channels' && method === 'GET') {
    const user = await verifyToken(req, res); if (!user) return;
    const snap = await db.collection('channels').orderBy('createdAt').get();
    const channels = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    return res.json(channels);
  }

  // ── POST /channels ─────────────────────────────────────────────────────────
  if (path === '/channels' && method === 'POST') {
    const user = await verifyToken(req, res); if (!user) return;
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'name required' });
    const slug = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    const ref = await db.collection('channels').add({
      name, slug, createdBy: user.uid, createdAt: new Date().toISOString(),
    });
    return res.json({ id: ref.id, name, slug });
  }

  // ── GET /messages?channel=x | ?dmWith=uid ─────────────────────────────────
  if (path === '/messages' && method === 'GET') {
    const user = await verifyToken(req, res); if (!user) return;
    const { channel, dmWith } = req.query;
    let query;
    if (channel) {
      query = db.collection('messages')
        .where('channel', '==', channel)
        .orderBy('createdAt', 'desc').limit(50);
    } else if (dmWith) {
      const pair = [user.uid, dmWith].sort().join('_');
      query = db.collection('messages')
        .where('dmPair', '==', pair)
        .orderBy('createdAt', 'desc').limit(50);
    } else {
      return res.status(400).json({ error: 'channel or dmWith required' });
    }
    const snap = await query.get();
    const msgs = snap.docs.map(d => ({ id: d.id, ...d.data() })).reverse();
    return res.json(msgs);
  }

  // ── POST /messages ─────────────────────────────────────────────────────────
  if (path === '/messages' && method === 'POST') {
    const user = await verifyToken(req, res); if (!user) return;
    const { text, channel, dmWith } = req.body;
    if (!text && !channel && !dmWith) return res.status(400).json({ error: 'Missing fields' });
    const doc = {
      text: text || '',
      authorUid: user.uid,
      authorName: user.name || user.email,
      authorPhoto: user.picture || null,
      createdAt: new Date().toISOString(),
    };
    if (channel) { doc.channel = channel; }
    if (dmWith)  { doc.dmPair = [user.uid, dmWith].sort().join('_'); doc.dmWith = dmWith; doc.dmFrom = user.uid; }
    const ref = await db.collection('messages').add(doc);
    return res.json({ id: ref.id, ...doc });
  }

  // ── POST /upload ───────────────────────────────────────────────────────────
  if (path === '/upload' && method === 'POST') {
    const user = await verifyToken(req, res); if (!user) return;
    let parsed;
    try { parsed = await parseMultipart(req); } catch (e) { return res.status(400).json({ error: 'Bad upload' }); }
    const { fields, files } = parsed;
    if (!files.length) return res.status(400).json({ error: 'No file' });

    const file = files[0];
    const ext = file.info.filename.split('.').pop();
    const dest = `uploads/${user.uid}/${Date.now()}-${file.info.filename}`;
    const gcsFile = storage.file(dest);
    await gcsFile.save(file.buffer, { contentType: file.info.mimeType, public: true });
    const url = `https://storage.googleapis.com/${storage.name}/${dest}`;

    // Post message with attachment
    const doc = {
      text: fields.text || '',
      fileUrl: url,
      fileName: file.info.filename,
      fileMime: file.info.mimeType,
      authorUid: user.uid,
      authorName: user.name || user.email,
      authorPhoto: user.picture || null,
      createdAt: new Date().toISOString(),
    };
    if (fields.channel) doc.channel = fields.channel;
    if (fields.dmWith) {
      doc.dmPair = [user.uid, fields.dmWith].sort().join('_');
      doc.dmWith = fields.dmWith;
      doc.dmFrom = user.uid;
    }
    const ref = await db.collection('messages').add(doc);
    return res.json({ id: ref.id, ...doc });
  }

  // ── GET /users ─────────────────────────────────────────────────────────────
  if (path === '/users' && method === 'GET') {
    const user = await verifyToken(req, res); if (!user) return;
    const snap = await db.collection('users').get();
    const users = snap.docs.map(d => ({ uid: d.id, ...d.data() })).filter(u => u.uid !== user.uid);
    return res.json(users);
  }

  // ── POST /users/me  (upsert profile on login) ──────────────────────────────
  if (path === '/users/me' && method === 'POST') {
    const user = await verifyToken(req, res); if (!user) return;
    await db.collection('users').doc(user.uid).set({
      name: user.name || user.email,
      email: user.email,
      photo: user.picture || null,
      lastSeen: new Date().toISOString(),
    }, { merge: true });
    return res.json({ ok: true });
  }

  res.status(404).json({ error: 'Not found' });
});
