# Relay Chat — Setup Guide

## Stack
- **Backend**: Google Cloud Functions (Node.js 20)
- **Auth**: Firebase Authentication (Google OAuth)
- **Database**: Firestore (real-time messages & channels)
- **Storage**: Firebase Storage (file uploads)
- **Frontend**: Vanilla HTML/CSS/JS (no build step)

---

## 1. Firebase Project Setup

1. Go to [Firebase Console](https://console.firebase.google.com/) → **Add project**
2. Enable **Google sign-in**: Authentication → Sign-in method → Google → Enable
3. Create a **Firestore** database (start in production mode)
4. Enable **Storage** (start in production mode)

### Get your Firebase config (for the frontend)
Firebase Console → Project Settings → Your apps → Add web app → copy the `firebaseConfig` object.

Paste it into `public/index.html` replacing the `YOUR_*` placeholders.

### Get your Service Account (for the backend)
Firebase Console → Project Settings → Service accounts → Generate new private key → download JSON.

---

## 2. Deploy Security Rules

```bash
npm install -g firebase-tools
firebase login
firebase init   # select Firestore + Storage, link to your project

firebase deploy --only firestore:rules
firebase deploy --only storage:rules
```

---

## 3. Deploy the Cloud Function

### Set environment variables

In **Google Cloud Console** → Cloud Functions → your function → Edit → Environment variables, add:

| Variable | Value |
|---|---|
| `FIREBASE_SERVICE_ACCOUNT` | Contents of your service account JSON (minified, one line) |
| `FIREBASE_STORAGE_BUCKET` | `your-project.appspot.com` |
| `ALLOWED_ORIGIN` | Your frontend URL (or `*` for dev) |

### Deploy

```bash
gcloud functions deploy api \
  --runtime nodejs20 \
  --trigger-http \
  --allow-unauthenticated \
  --entry-point api \
  --region us-central1
```

Copy the deployed URL (e.g. `https://us-central1-yourproject.cloudfunctions.net/api`) and paste it into `public/index.html` as the `API` constant.

---

## 4. Host the Frontend

**Option A — Firebase Hosting (recommended)**
```bash
firebase init hosting   # public dir = "public"
firebase deploy --only hosting
```

**Option B — Any static host** (Netlify, Vercel, GitHub Pages)  
Just upload the `public/` folder.

---

## 5. Local Development

```bash
npm install
cp .env.example .env   # fill in your values
npm run dev            # runs on http://localhost:8080
```

Then open `public/index.html` in a browser (use Live Server or similar).  
Set `API` in `index.html` to `http://localhost:8080`.

---

## File Structure

```
├── index.js           ← Cloud Function (all API routes)
├── package.json
├── firestore.rules    ← Deploy to Firestore
├── storage.rules      ← Deploy to Firebase Storage
├── .env.example
└── public/
    └── index.html     ← Frontend (single file, no build needed)
```

## API Routes

| Method | Path | Description |
|---|---|---|
| GET | `/channels` | List all channels |
| POST | `/channels` | Create a channel `{ name }` |
| GET | `/messages?channel=id` | Get channel messages |
| GET | `/messages?dmWith=uid` | Get DM messages |
| POST | `/messages` | Send a text message |
| POST | `/upload` | Upload file + optional message |
| GET | `/users` | List all users |
| POST | `/users/me` | Upsert own profile |

All routes require `Authorization: Bearer <firebase-id-token>`.
